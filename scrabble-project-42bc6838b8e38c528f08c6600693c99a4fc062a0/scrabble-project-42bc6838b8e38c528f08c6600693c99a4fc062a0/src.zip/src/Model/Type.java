package Model;

/**
 * enum for the types of squares*/
public enum Type {
        TRIPLE_WORD, DOUBLE_WORD, CENTER, TRIPLE_LETTER, DOUBLE_LETTER, NORMAL
}

package Exceptions;

public class WrongOrientationException extends Exception{
    public WrongOrientationException(String message){
        super(message);
    }
}

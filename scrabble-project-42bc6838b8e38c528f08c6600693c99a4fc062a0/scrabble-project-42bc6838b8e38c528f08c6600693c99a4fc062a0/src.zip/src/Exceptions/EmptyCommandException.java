package Exceptions;

public class EmptyCommandException extends Exception{
    public EmptyCommandException(String message){
        super(message);
    }
}

package Exceptions;

public class SquareNotEmptyException extends Exception{
    public SquareNotEmptyException(String message){
        super(message);
    }
}
